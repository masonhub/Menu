﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class GradientHp : MonoBehaviour
{
    public Image hpbar;
    public float currenthp;
    public float maxhhp;
    public Gradient gradient;

    // Start is called before the first frame update
    public void Sethp(float hp)
    {
        hpbar.fillAmount = Mathf.Clamp01(hp / maxhhp);

        hpbar.color = gradient.Evaluate(hpbar.fillAmount); // Calculate color at an given time 
    }

    // Update is called once per frame
    void Update()
    {
        Sethp(currenthp);   
    }
}
