﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DisableCube : MonoBehaviour
{
    public KeyCode disableKey = KeyCode.T;
    public KeyCode anotherActionKey = KeyCode.C;
    bool isWaiting = false;
    public GameObject DisableThis;
    string WhichKey = "";
    private void OnGUI()
    {
        if (isWaiting == true)
        {
            if (Event.current.isKey)
            {
                switch (WhichKey)
                {
                    case "Disable":
                        disableKey = Event.current.keyCode;
                        break;
                    case "AnotherAction":
                        anotherActionKey = Event.current.keyCode;
                        break;
                }
                isWaiting = false;
            }
        }
    }
    public void WaitForKeyInput(string KeyChanging)
    {
        isWaiting = true;
        WhichKey = KeyChanging;
    }
    // Update is called once per frame
    public void changekey()
    {
        
    }

    void Update()
    {
        if (Input.GetKeyDown(disableKey))// && Time.timeScale == 1 )// > 0 
        {
            if(DisableThis.activeSelf == true)
            {
                DisableThis.SetActive(false);
            }
            else
            {
                DisableThis.SetActive(true);
            }
            
        }

    }
}
