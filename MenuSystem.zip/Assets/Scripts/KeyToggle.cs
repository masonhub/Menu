﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyToggle : MonoBehaviour
{
    public KeyCode ToogleKey;
    public KeyCode Color;

    public GameObject CurrentKey;
    public GameObject PressKey, MenuCanvas;
    // Start is called before the first frame update
    void Start()
    {
        PressKey.SetActive(true);
        MenuCanvas.SetActive(false);

    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(Color))
        {
           
        }
        if (Input.GetKeyDown(ToogleKey))
        {
            MenuCanvas.SetActive(false);
        }
    }

    private void OnGUI()
    {
        
        ToogleKey = Event.current.keyCode;
        Color = Event.current.keyCode;
    }
}
