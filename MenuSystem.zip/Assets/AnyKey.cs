﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnyKey : MonoBehaviour
{
    //Variables 
    public GameObject PressKey, Menu;

    private void OnGUI()
    {
        if (Event.current.isKey)
        {
           // gameObject.SetActive(false);
        }
    }


    //Load to Key Press
    private void Update()
    {
        if (Input.anyKey)
        {
            Menu.SetActive(true);
            PressKey.SetActive(false);
        }
    }
}
